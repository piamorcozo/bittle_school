<?php 

include 'connect.php';

//login for student
if(isset($_POST['logins'])){
    $un = $_POST['suname'];
    $pw = $_POST['spword'];

    $st1 = "SELECT * FROM student_acc WHERE SUname='$un' AND SPass='$pw'";
    $quer1 = mysqli_query($conn, $st1);
    $cn = mysqli_num_rows($quer1);
    if($cn>0){
        $cc = mysqli_fetch_assoc($quer1);
      //  echo 'nays';
      $_SESSION['studentid'] = $cc['StudentID'];
      $_SESSION['suname'] = $cc['SFname']." ".$cc['SLname'];
      $_SESSION['stat'] = 'Active';
    header('location: studenthome.php');
  
        }
    else{
        
        $_SESSION['message'] = "Incorrect credentials.";
        $_SESSION['status'] = "error";
        header('location: index.php');
       
    
    //         header('location: index.php');
    //     $_SESSION['message'] = "Incorrect password/username. Please try again.";
    // $_SESSION['msg_type'] = "danger";
    }
}

//login for teacher
if(isset($_POST['logint'])){
    $un = $_POST['suname'];
    $pw = $_POST['spword'];

    $st1 = "SELECT * FROM faculty_acc WHERE FUname='$un' AND FPass='$pw'";
    $quer1 = mysqli_query($conn, $st1);
    $cn = mysqli_num_rows($quer1);
    if($cn>0){
        $res = mysqli_fetch_assoc($quer1);
        $facid = $res['FacultyID'];
      //  echo 'nays';
      $getf = "SELECT FFname, FLname FROM faculty_acc WHERE FacultyID = '$facid'";
      $q = mysqli_query($conn, $getf);
      $res2 = mysqli_fetch_assoc($q);
      

      $getsub = "SELECT * FROM subjects WHERE FacultyID='$facid'";
      $getsubq = mysqli_query($conn,$getsub);
      $sub = mysqli_fetch_assoc($getsubq);
      

    $_SESSION['subjectid'] = $sub['SubjectID'];
    $_SESSION['teacherid'] = $facid;
    $_SESSION['tuname'] = $res2['FFname']." ".$res2['FLname'];
    $_SESSION['stat'] = 'Active';
    header('location: teacherhome.php');
    
  
        }
    else{
        $_SESSION['message'] = "Incorrect credentials.";
        $_SESSION['status'] = "error";
        header('location: loginteacher.php');
       
    
    //         header('location: index.php');
    //     $_SESSION['message'] = "Incorrect password/username. Please try again.";
    // $_SESSION['msg_type'] = "danger";
    }
}

//register for student
if(isset($_POST['sregister'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $pw = $_POST['pword'];
    $un = $_POST['uname'];

   $insert = "INSERT INTO student_acc(SFname, SLname, SAge, SGender, SUname, SPass) VALUES('$fname','$lname','$age','$gender','$un','$pw')";
    $infind1 = mysqli_query($conn, $insert);
    $_SESSION['message'] = "Registered succesfully!";
        $_SESSION['status'] = "success";
        header('location: index.php');




}

//check username for student if it exists
if(isset($_POST['un'])){
    $un = $_POST['un'];
    $st1 = "SELECT * FROM student_acc WHERE SUname='$un'";
    $quer1 = mysqli_query($conn, $st1);
    $cn = mysqli_num_rows($quer1);
    if($cn>0){
        echo "1";

    }else{
        echo "0";
    }


}

//register for teacher
if(isset($_POST['tregister'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $pw = $_POST['pword'];
    $un = $_POST['uname'];
    $sub = $_POST['subjs'];

   $insert = "INSERT INTO faculty_acc(FFname, FLname, FGender, FUname, FPass) VALUES('$fname','$lname','$gender','$un','$pw')";
   $infind1 = mysqli_query($conn, $insert);

   $getlatest = "SELECT * FROM faculty_acc ORDER BY FacultyID DESC LIMIT 1";
   $latq = mysqli_query($conn, $getlatest);
   $l = mysqli_fetch_assoc($latq);
   $fid = $l['FacultyID'];

   $upd = "UPDATE subjects SET FacultyID='$fid' WHERE SubjectID='$sub'";
   
   $updq = mysqli_query($conn, $upd);

    $_SESSION['message'] = "Registered succesfully!";
        $_SESSION['status'] = "success";
        header('location: loginteacher.php');




}
//check username for teacher if it exists
if(isset($_POST['tun'])){
    $un = $_POST['tun'];
    $st1 = "SELECT * FROM faculty_acc WHERE FUname='$un'";
    $quer1 = mysqli_query($conn, $st1);
    $cn = mysqli_num_rows($quer1);
    if($cn>0){
        echo "1";

    }else{
        echo "0";
    }


}

?>