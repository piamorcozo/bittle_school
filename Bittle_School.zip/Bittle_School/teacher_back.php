<?php
include 'connect.php';

if(isset($_GET['studid'])){
    $_SESSION['studid'] = $_GET['studid'];
    header('location: teacherhome.php');
}
if(isset($_POST['addgrade'])){
    $grade = $_POST['gradev'];
    $sem = $_POST['semd'];
    $subj = $_POST['subid'];
    $student = $_POST['stu'];
    
    $insert = "INSERT INTO grades(SemID, SubjectID, StudentID, Grade) VALUES('$sem','$subj','$student','$grade')";
  
    $infind1 = mysqli_query($conn, $insert);
    $_SESSION['message'] = "Grade added succesfully!";
        $_SESSION['status'] = "success";
        header('location: teacherhome.php');
}

if(isset($_POST['subedit'])){
    $gid = $_POST['gradeid'];
    $gr = $_POST['egrade'];

    $edit = "UPDATE grades SET Grade='$gr' WHERE GradeID='$gid'";
    $kk = mysqli_query($conn, $edit);

     $_SESSION['message'] = "Grade updated succesfully!";
     $_SESSION['status'] = "success";
    header('location: teacherhome.php');
}
if(isset($_POST['delete'])){
    $gid = $_POST['gradeid'];
   // $gr = $_POST['egrade'];

    $edit = "DELETE FROM grades WHERE GradeID='$gid'";
    $kk = mysqli_query($conn, $edit);

     $_SESSION['message'] = "Grade deleted succesfully!";
     $_SESSION['status'] = "success";
    header('location: teacherhome.php');
}
if(isset($_POST['tlogout'])){

	
    session_start();
session_destroy();
$_SESSION = array();
header("location: loginteacher.php");

}
?>