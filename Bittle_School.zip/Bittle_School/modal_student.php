<div class="modal fade" id="studentinfo<?php echo $_SESSION['studentid']; ?>" name="tryname2">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document" >
            <div class="modal-content">
                <div class="modal-header text-center" >
                    <h6 class="modal-title w-100" style="color: gray">Information</h6>                                              
                </div>
        <form method="POST" action="editmemquer.php" enctype="multipart/form-data" name="add_name" id="addm" >
            <div class="modal-body" >
            <div class="row">
                <?php 
                    $sid = $_SESSION['studentid'];
                    $ff = "SELECT * FROM student_acc WHERE StudentID='$sid'";
                    $ffq = mysqli_query($conn, $ff);
                    $k = mysqli_fetch_assoc($ffq);
                ?>
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" value="<?php echo $k['SFname']; ?>" class="form-control"  readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" value="<?php echo $k['SLname']; ?>" class="form-control"  readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Age</label>
                            <input type="text" name="fname" value="<?php echo $k['SAge']; ?>" class="form-control"  readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Gender</label>
                            <input type="text" name="lname" value="<?php echo $k['SGender']; ?>" class="form-control"  readonly>
                        </div>
                    </div>
              
             
                    </div>
            
                 </form>
            </div>
            </div>
            </div>