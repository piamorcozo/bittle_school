<div class="modal fade" id="studentinfo<?php echo $k['StudentID']; ?>" name="tryname2">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document" >
            <div class="modal-content">
                <div class="modal-header text-center" >
                    <h6 class="modal-title w-100" style="color: gray">Student Information</h6>                                              
                </div>
        <form method="POST" action="editmemquer.php" enctype="multipart/form-data" name="add_name" id="addm" >
            <div class="modal-body" >
            <div class="row">
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" value="<?php echo $k['SFname']; ?>" class="form-control"  readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" value="<?php echo $k['SLname']; ?>" class="form-control"  readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Age</label>
                            <input type="text" name="fname" value="<?php echo $k['SAge']; ?>" class="form-control"  readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Gender</label>
                            <input type="text" name="lname" value="<?php echo $k['SGender']; ?>" class="form-control"  readonly>
                        </div>
                    </div>
              
             
                    </div>
            
                 </form>
            </div>
            </div>
            </div>
<!-- modal for editing grades -->
            <div class="modal fade" id="editgrades<?php echo $g['GradeID']; ?>" name="">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document" >
            <div class="modal-content">
                <div class="modal-header text-center" >
                    <h6 class="modal-title w-100" style="color: gray">Edit Student Grade</h6>                                              
                </div>
        <form method="POST" action="teacher_back.php" enctype="multipart/form-data" >
            <div class="modal-body" >
            <div class="row">
            
            <input type="hidden" name="gradeid" value="<?php echo $g['GradeID']; ?>">
                        <div class="col-md-6 form-group">
                            <label>Semester</label>
                            <input type="text" name="esem" value="<?php echo $j['Semester']; ?>" class="form-control"  readonly>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Grade</label>
                            <input type="number" name="egrade" value="<?php echo $g['Grade']; ?>" class="form-control"  >
                        </div>
                    </div>
                    <div class="d-flex flex-row-reverse bd-highlight">
                    
                    <button type="submit" name="subedit" class="btn btn-success mx-2" >Save</button>
                    <button type="button" name="cancel" class="btn btn-dark" data-bs-dismiss="modal">Cancel</button>
                    </div>
              
             
                    </div>
            
                 </form>
            </div>
            </div>
            </div>
      
            <!-- modal for deleting grades -->
            <div class="modal fade" id="deletecon<?php echo $g['GradeID']; ?>" name="">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document" >
            <div class="modal-content">
                <div class="modal-header text-center" >
                    <h6 class="modal-title w-100" style="color: gray"></h6>                                              
                </div>
        <form method="POST" action="teacher_back.php" enctype="multipart/form-data" >
            <div class="modal-body" >
            <div class="align-items-center p-3">
            
            <input type="hidden" name="gradeid" value="<?php echo $g['GradeID']; ?>">
                       <h4>Are you sure you want to delete this record?</h4>
                       <p>This action is irreversible.</p>
                    </div>
                    <div class="d-flex flex-row-reverse bd-highlight">
                    
                    <button type="submit" name="delete" class="btn btn-danger mx-2" >Yes</button>
                    <button type="button" name="cancel" class="btn btn-dark" data-bs-dismiss="modal">Cancel</button>
                    </div>
              
             
                    </div>
            
                 </form>
            </div>
            </div>
            </div>
      