<?php 
include 'connect.php';

if(isset($_POST['sem'])){
    $sem = $_POST['sem'];
    $student = $_SESSION['studentid'];
    $no=1;
    $getgrades = "SELECT * FROM grades WHERE StudentID='$student' AND SemID='$sem'";
    $getgradesq = mysqli_query($conn, $getgrades);
    while($p = mysqli_fetch_assoc($getgradesq)){
        $subid = $p['SubjectID'];
        

        $getsub = "SELECT * FROM subjects WHERE SubjectID='$subid'";
        $getsubq = mysqli_query($conn, $getsub);
        $h = mysqli_fetch_assoc($getsubq);
        $tid = $h['FacultyID'];

        $getfac = "SELECT * FROM faculty_acc WHERE FacultyID='$tid'";
        $getfacq = mysqli_query($conn, $getfac);
        $f = mysqli_fetch_assoc($getfacq);
        

        ?>
        <tr>
            <td> <?php echo $no; ?> </td>
            <td><?php echo $h['Subject']; ?></td>
            <td><?php echo $f['FFName']." ".$f['FLname']; ?></td>
            <td><?php echo $p['Grade']; ?></td>
        </tr>
        <?php
    }
}
?>