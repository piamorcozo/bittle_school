<?php include 'connect.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logos.png">
  <link rel="icon" type="image/png" href="./assets/img/logos.png">
  
  <title>Register Student
  </title>
 <?php include 'header.php'; ?>
</head>

<!-- <body style="background-image: url(images/bg1.png);"> -->
<body class="">
 
  <main class="main-content  mt-0">
    <section>
      <div class="page-header min-vh-100">
        <div class="container">
          <div class="row">
            <div class="col-xl-5 col-lg-5 col-md-7 d-flex flex-column mx-lg-0 mx-auto">
              <div class="card card-plain">
                <div class="card-header pb-0 text-start">
                  <h4 class="font-weight-bolder">Create your Account</h4>
                  <p class="mb-0">Please fill up the fields.</p>
                </div>
                <div class="card-body">
                  <form role="form" method="POST" action="login.php">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <input type="text" name="fname" class="form-control" placeholder="First name" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <input type="text" name="lname" class="form-control" placeholder="Last name" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <input type="number" name="age" class="form-control" placeholder="Age" aria-label="Username" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1" value="Female" checked>
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Female
                                </label>
                                </div>
                                <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="Male" >
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Male
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="text" id="uname" name="uname" class="form-control" placeholder="Enter Username" required>
                    </div>
                    <div class="mb-3">
                        <div class="input-group" id="showp">
                            <input type="password" name="pword" id="pword" class="form-control" placeholder="Enter password" required>
                            <span class="input-group-text"   id="eye" style="cursor: pointer"><i  class="fa fa-eye-slash"></i></span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="password" name="pwordc" id="pwordc" class="form-control" placeholder="Re-enter password" required>
                    </div>
                    <div class="mb-3" id="invalid">
                        <i style="color: red;">Password doesn't match!</i>
                    </div>
                    <div class="mb-3" id="unexists">
                        <i style="color: red;">Username already exists!</i>
                    </div>
                    
                    
                
                    <div class="text-center">
                      <button type="submit" name="sregister" id="reg" class="btn btn-lg btn-primary btn-lg w-100 mt-4 mb-0">Register</button>
                
                    </div>
                  </form>
                </div>
                <div class="card-footer text-center pt-0 px-lg-2 px-1">
                  <p class="mb-4 text-sm mx-auto">
                   Nevermind.
                    <a href="index.php" class="text-primary text-gradient font-weight-bold">Login now</a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 end-0 text-center justify-content-center flex-column">
              <div class="position-relative h-100 m-3 px-7 border-radius-lg d-flex flex-column justify-content-center overflow-hidden" style="background-image:url('assets/img/bb.png');
          background-size: cover;">
            
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/argon-dashboard.min.js?v=2.0.4"></script>
</body>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <script src="./assets/js/sweetalert2.js"></script>
  <!-- <script src="sweetalert2.all.min.js"></script> -->
  <script>
    $("#invalid").hide();
    $("#unexists").hide();

    $('#pwordc').keyup(function(){
 var search = $(this).val();
  if(search != $('#pword').val())
  {
    $("#invalid").show();
    $("#reg").attr('disabled', true);

  }
  else{
    $("#invalid").hide();
    $("#reg").attr('disabled', false);
  }
  
 });

 $("#eye").on('click', function(event) {
        event.preventDefault();
        if($('#showp input').attr("type") == "text"){
            $('#showp input').attr('type', 'password');
            $('#showp i').addClass( "fa-eye-slash" );
            $('#showp i').removeClass( "fa-eye" );
        }else if($('#showp input').attr("type") == "password"){
            $('#showp input').attr('type', 'text');
            $('#showp i').removeClass( "fa-eye-slash" );
            $('#showp i').addClass( "fa-eye" );
        }
    });


    //checking if username exists
    function check(un)
    {
        $.ajax({
            url:"login.php",
            method:"POST",
            data:{un:un},
            success:function(data)
            {
                var da = data;
                    if(da==1){
                        $("#unexists").show();
                        $("#reg").attr('disabled', true);
                       
                    }
                    else{
                        $("#unexists").hide();
                        $("#reg").attr('disabled', false);
                       
                    }
            }
        });
    }
    $('#uname').keyup(function(){
 var search = $(this).val();
  if(search != "")
  {
    check(search);
  }
  else{
    $("#unexists").hide();
  }
  
 });

    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/argon-dashboard.min.js?v=2.0.4"></script>

  <?php
  if(isset($_SESSION['status']) && $_SESSION['status'] !=''){
    ?>
    <script>
        Swal.fire({
            icon: "<?php  echo $_SESSION['status']; ?>",
            text: "<?php  echo $_SESSION['message']; ?>",
        
            });
     

    </script>
    <?php
 
    unset($_SESSION['status']);
  }
  
  ?>
</body>

</html>