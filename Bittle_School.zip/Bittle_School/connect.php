<?php
session_start();

$errors = array(); 
$servername = "localhost";
$username = "root";
$password = ""; 
$db = "bittel_school";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);
?>