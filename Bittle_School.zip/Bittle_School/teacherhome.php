<?php include 'connect.php'; 

if($_SESSION['stat']!="Active")
{
    header("location:loginteacher.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logos.png">
  <link rel="icon" type="image/png" href="./assets/img/logos.png">
  
  <title>Teacher Home
  </title>
 <?php include 'header.php'; ?>
</head>
 
<body class="bg-gray-100">
  <div class="min-height-300 bg-primary position-absolute w-100"></div>
 
  <main class="main-content position-relative border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl " id="navbarBlur" data-scroll="false">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
         
          <h4 class="text-white mb-2">Welcome back, <?php echo $_SESSION['tuname']; ?>!</h4>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
            
          </div>
          <ul class="navbar-nav  justify-content-end">
            <li class="nav-item d-flex align-items-center">
              <form method="POST" action="teacher_back.php">
              <button type="submit" name="tlogout" class="btn btn-sm btn-danger" ><i class="fa fa-share me-sm-1"></i>
                <span class="d-sm-inline d-none">Logout</span></button>
              </form>
            </li>
            
           
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Your Subject</p>
                    <h5 class="font-weight-bolder">
                      <?php 
                      $sis = $_SESSION['subjectid'];
                        $sub = "SELECT * FROM subjects WHERE SubjectID='$sis'";
                        $subq = mysqli_query($conn, $sub);
                        $m = mysqli_fetch_assoc($subq);
                        echo $m['Subject'];
                      
                      ?>
                    </h5>
                    
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow-primary text-center rounded-circle">
                    <i class="fa fa-book text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Male Students</p>
                    <h5 class="font-weight-bolder">
                     <?php
                      $getf = "SELECT * FROM student_acc WHERE SGender='Male'";
                      $q = mysqli_query($conn, $getf);
                      $male = mysqli_num_rows($q);
                      echo $male;

                     ?>
                    </h5>
                  
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-info shadow-info text-center rounded-circle">
                    <i class="fa fa-male text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Female Students</p>
                    <h5 class="font-weight-bolder">
                     <?php
                      $getf = "SELECT * FROM student_acc WHERE SGender='Female'";
                      $q = mysqli_query($conn, $getf);
                      $fmale = mysqli_num_rows($q);
                      echo $fmale;

                     ?>
                    </h5>
                  
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-danger shadow-danger text-center rounded-circle">
                    <i class="fa fa-female text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Total Students</p>
                    <h5 class="font-weight-bolder">
                     <?php
                      $getf = "SELECT * FROM student_acc";
                      $q = mysqli_query($conn, $getf);
                      $all = mysqli_num_rows($q);
                      echo $all;

                     ?>
                    </h5>
                  
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-success shadow-success text-center rounded-circle">
                    <i class="fa fa-user-friends text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
     
      </div>
    
      <div class="row mt-4">
        <div class="col-lg-7 mb-lg-0 mb-4">
          <div class="card ">
            <div class="card-header pb-0 p-3">
              <div class="d-flex justify-content-between">
                <h6 class="mb-2">Students list</h6>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center ">
                <thead style="text-align: center;">
                    <tr>
                        <th>No.</th>
                        <th>Student Name</th>
                        <th>Section</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody style="text-align: center;">
                    <?php
                        $num = 1;
                        $gets = "SELECT * FROM student_acc";
                        $getq = mysqli_query($conn, $gets);
                        while($k = mysqli_fetch_assoc($getq)){
                    ?>
                        <tr>
                            <td><?php echo $num; ?></td>
                            <td><?php echo $k['SFname']." ".$k['SLname']; ?></td>
                            <td>1st year Diamond</td>
                            <td>
                            <button type="button"  data-bs-toggle="modal" data-bs-target="#studentinfo<?php echo $k['StudentID']; ?>" class="btn btn-sm btn-primary btn-sm mt-4 mb-0">Information</button>
                            <a <?php echo 'href="teacher_back.php?studid='.$k['StudentID'].'"'; ?> class="btn btn-sm btn-dark btn-sm mt-4 mb-0">Grades</a>
                            <!-- <button type="button" id="opengr" name="<?php echo $k['StudentID']; ?>" class="btn btn-sm btn-dark btn-sm mt-4 mb-0">Grades</button> -->
                            </td>
                        </tr>
                        <?php 
                            
                            $num++;
                            include 'modal_teacher.php';
                        } 
                    ?>
                </tbody>
                
            
             
              </table>
            </div>
          </div>
        </div>
        <?php
                                    if(isset($_SESSION['studid'])){
                                        $studentid = $_SESSION['studid'];
                                        $getst = "SELECT * FROM student_acc WHERE StudentID='$studentid'"; 
                                        $getstq = mysqli_query($conn, $getst);
                                        $st = mysqli_fetch_assoc($getstq);
                                      
                                        ?>
        <div class="col-lg-5" id="edit">
          <div class="card">
            <div class="row pb-0 p-3 ">
                                      
              <div class="col-md-6">
              <h4 class=""><?php echo $st['SFname']." ".$st['SLname']; ?>'s Grades</h4>
              </div>
              <div class="col-md-6 d-flex justify-content-end">
                <?php 
                $subid = $_SESSION['subjectid'];
                  //check if fourth semester already has grades
                  $ch = "SELECT * FROM grades WHERE StudentID='$studentid' AND SubjectID='$subid' ORDER BY SemID DESC LIMIT 1;";
                  $chq = mysqli_query($conn, $ch);
                  $c = mysqli_fetch_assoc($chq);
                  if($c['SemID'] != '4'){
                ?>
              <button class="btn btn-success mx-2" id="showadd" ><i class="fa fa-plus"></i></button>
              <?php } ?>
                <button class="btn btn-danger" id="closeg" >X</button>
              </div>
              
                                  
            </div>
            <div class="card-body p-3">
              <div id="addcard">
                <form method="POST" action="teacher_back.php">
                  
                  <div class="row mx-2">
                    <div class="col-md-6">
                    <label>Choose semester</label>
                    <select class="form-select" name="semd" aria-label="">
                      <?php
                        //get all sem that doesn't have grades
                        
                        
                        $sm = "SELECT SemID FROM grades WHERE StudentID='$studentid' AND SubjectID='$subid'";
                        $smq = mysqli_query($conn, $sm);
                        $check = mysqli_num_rows($smq);
                        if($check>0){
                          $notsem = array();
                          $semin = array();
                          $semname = array();

                          while($ss = mysqli_fetch_assoc($smq)){
                            $sid = $ss['SemID'];
                              array_push($notsem, $sid);
                          }
                          $getsem = "SELECT * FROM semesters WHERE SemID NOT IN(".implode(",",$notsem).")";
                          $getsemq = mysqli_query($conn, $getsem);
                          
                          //.implode(",",$ids_to_exclude).
                          while($gg = mysqli_fetch_assoc($getsemq)){
              
                            array_push($semin, $gg['SemID']);
                            array_push($semname, $gg['Semester']);
                          }
                          for($i=0; $i<sizeof($semin); $i++){
                      ?>
                     
                          <option name="semesterv" value="<?php echo $semin[$i]; ?>" ><?php echo $semname[$i]; ?></option>
                      <?php }}
                      else{
                        $se = "SELECT * FROM semesters";
                        $seq = mysqli_query($conn, $se);
                        while($h = mysqli_fetch_assoc($seq)){
                      ?>
                       <option name="semesterv" value="<?php echo $h['SemID']; ?>" ><?php echo $h['Semester']; ?></option>
                      <?php }
                    } ?>
                    </select>
                    </div>
                    <div class="col-md-6">
                      <label>Enter grade</label>
                      <input type="number" name="gradev" class="form-control" value="0" >
                    </div>
                  </div>
                  <input type="hidden"name="stu"  value="<?php echo $studentid; ?>" >
                  <input type="hidden" name="subid" value="<?php echo $_SESSION['subjectid']; ?>" >
                  
                  <div class="row mt-3 mx-3">
                    <div class="col-md-6 ">
                      <button type="button" class="btn btn-dark w-100" id="canceladd" >Cancel</button>
                    </div>
                    <div class="col-md-6">
                    <button class="btn btn-success w-100" type="submit" name="addgrade" >Add Grade</button>
                    </div>
                  
                  </div>
                </form>
              </div>
              <br>
            <div class="table-responsive">
              <table class="table align-items-center ">
                <thead style="text-align: center;">
                    <tr>
                        <th>Semester</th>
                        <th>Grades</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody style="text-align: center;">
                    <?php
                        $ave = 0;
                        $num = 0;
                        $gets = "SELECT * FROM grades WHERE StudentID='$studentid' AND SubjectID='$subid'";
                        $getq = mysqli_query($conn, $gets);
                        while($g = mysqli_fetch_assoc($getq)){
                          $semid = $g['SemID'];
                          $sem = "SELECT * FROM semesters WHERE SemID='$semid'";
                          $semq = mysqli_query($conn, $sem);
                          $j = mysqli_fetch_assoc($semq);
                    ?>
                        <tr >
                            <td ><?php echo $j['Semester']; ?></td>
                            <td><?php echo $g['Grade']; ?></td>
                            <td>
                            <button type="button" name="egmod" data-bs-toggle="modal" data-bs-target="#editgrades<?php echo $g['GradeID']; ?>" class="btn btn-sm btn-primary btn-sm mt-4 mb-0"><i class="fa fa-edit"></i></button>
                            <button type="button" name="delmod" data-bs-toggle="modal" data-bs-target="#deletecon<?php echo $g['GradeID']; ?>" id="deletegr"  class="btn btn-sm btn-danger btn-sm mt-4 mb-0"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php 
                            include 'modal_teacher.php';
                            $num++;
                            $ave += floatval($g['Grade']);
                        } 
                    ?>
                </tbody>
              
                
              
             
              </table>
              <div class="p-3 col-12 text-end">
                  <?php 
                  if($num>0){
                    $ave/=$num;
                    echo '<h6> Average Grade: <b>'.round($ave,2).'</b></h6>';
                  }
                  
                  ?>
              </div>
              
            </div>
            </div>
          </div>
        </div>
        <?php unset($_SESSION['studid']);
      } ?>
      </div>
     
    </div>
  </main>
 
  <!--   Core JS Files   -->
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <script src="./assets/js/sweetalert2.js"></script>
  <script>
   
  </script>
  <script>
    var search = "";
    $("#addcard").hide();
    $("#closeg").on('click', function(event) {
        search = $(this).attr('name');
        $("#edit").hide();
        

    
    });
    $("#showadd").on('click', function(event) {
        //search = $(this).attr('name');
        $("#addcard").show();
    });
    $("#canceladd").on('click', function(event) {
        //search = $(this).attr('name');
        $("#addcard").hide();
    });
   
  </script>
  <?php
  if(isset($_SESSION['status']) && $_SESSION['status'] !=''){
    ?>
    <script>
        Swal.fire({
            icon: "<?php  echo $_SESSION['status']; ?>",
            text: "<?php  echo $_SESSION['message']; ?>",
        
            });
     

    </script>
    <?php
 
    unset($_SESSION['status']);
  }
  
  ?>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/argon-dashboard.min.js?v=2.0.4"></script>
</body>

</html>