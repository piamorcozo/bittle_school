<?php include 'connect.php'; 

if($_SESSION['stat']!="Active")
{
    header("location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/logos.png">
  <link rel="icon" type="image/png" href="./assets/img/logos.png">
  
  <title>Student Home
  </title>
 <?php include 'header.php'; ?>
</head>
 
<body class="bg-gray-100">
  <div class="min-height-300 bg-dark position-absolute w-100"></div>
 
  <main class="main-content position-relative border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl " id="navbarBlur" data-scroll="false">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
         
          <h4 class="text-white mb-2">Welcome back, <?php echo $_SESSION['suname']; ?>!</h4>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
            
          </div>
          <ul class="navbar-nav  justify-content-end">
            <li class="nav-item d-flex align-items-center">
              
              <button type="button" name="acc" data-bs-toggle="modal" data-bs-target="#studentinfo<?php echo $_SESSION['studentid']; ?>" class="btn btn-sm btn-primary" ><i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span></button>
          
            </li>
            <li class="nav-item d-flex align-items-center mx-2">
              <form method="POST" action="teacher_back.php">
              <button type="submit" name="tlogout" class="btn btn-sm btn-danger" ><i class="fa fa-share me-sm-1"></i>
                <span class="d-sm-inline d-none">Logout</span></button>
              </form>
            </li>
            <?php include 'modal_student.php'; ?>
            
           
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card mb-2">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Current Average Grade</p>
                    <h5 class="font-weight-bolder">
                      <?php 
                      $studentid =  $_SESSION['studentid'];
                        $getcursem = "SELECT DISTINCT(SemID) FROM grades WHERE StudentID=1 ORDER BY SemID DESC LIMIT 1";
                        $getcursemq = mysqli_query($conn, $getcursem);
                        $cur = mysqli_fetch_assoc($getcursemq);
                        $currentsem = $cur['SemID'];

                        $ave = 0;
                        $num = 0;
                        $sub = "SELECT * FROM grades WHERE StudentID='$studentid' AND SemID='$currentsem'";
                        $subq = mysqli_query($conn, $sub);
                        while($m = mysqli_fetch_assoc($subq)){
                            $ave+= $m['Grade'];
                            $num++;

                        }
                        if($num>0){
                            echo $ave/=$num;
                        }
                        
                      
                      ?>
                    </h5>
                    
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow-primary text-center rounded-circle">
                    <i class="fa fa-book text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <div class="card mb-2">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-uppercase font-weight-bold">Subjects</p>
                    <h5 class="font-weight-bolder">
                      <?php 
                    
                        $numsub = "SELECT * FROM subjects WHERE FacultyID!=0";
                        $numsubq = mysqli_query($conn, $numsub);
                        $nums = mysqli_num_rows($numsubq);
                        echo $nums;
                        
                      
                      ?>
                    </h5>
                    
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-primary shadow-primary text-center rounded-circle">
                    <i class="fa fa-book text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       
     
      </div>
    
      <div class="row mt-4">
        <div class="col-lg-7 mb-lg-0 mb-4">
          <div class="card ">
            <div class="card-header pb-0 p-3">
              <div class="d-flex justify-content-between">
                <?php 
                    $kk = "SELECT Semester FROM semesters WHERE SemID='$currentsem'";
                    $kkq = mysqli_query($conn, $kk);
                    $sk = mysqli_fetch_assoc($kkq);

                ?>
                <h6 class="mb-2">Grades for <?php echo $sk['Semester']; ?></h6>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center ">
                <thead style="text-align: center;">
                    <tr>
                        <th>No.</th>
                        <th>Subject</th>
                        <th>Teacher</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody style="text-align: center;">
                    <?php
                        $num = 1;
                        $gets = "SELECT * FROM grades WHERE StudentID='$studentid' AND SemID='$currentsem'";
                        $getq = mysqli_query($conn, $gets);
                        while($k = mysqli_fetch_assoc($getq)){
                            $subd = $k['SubjectID'];
                            $namesub = "SELECT * FROM subjects WHERE SubjectID = '$subd'";
                            $namesubq = mysqli_query($conn,$namesub);
                            $ns = mysqli_fetch_assoc($namesubq);
                            $facacc = $ns['FacultyID'];

                            $nameteach = "SELECT * FROM faculty_acc WHERE FacultyID='$facacc'";
                            $nameteachq = mysqli_query($conn, $nameteach);
                            $nt = mysqli_fetch_assoc($nameteachq);

                    ?>
                        <tr>
                            <td><?php echo $num; ?></td>
                            <td><?php echo $ns['Subject']; ?></td>
                            <td><?php echo $nt['FFName']." ".$nt['FLname']; ?></td>
                            <td><?php echo $k['Grade']; ?></td>
                        </tr>
                        <?php 
                            
                            $num++;
                            
                        } 
                    ?>
                </tbody>
                
            
             
              </table>
            </div>
          </div>
        </div>
    
        <div class="col-lg-5" id="">
            
          <div class="card">
            <div class="row pb-0 p-3 ">
                                      
              <div class="col-md-6">
              <h6 class="mx-3 mt-2">Other Semester Grades</h6>
              </div>
            
              
                                  
            </div>
            <div class="card-body">
            <?php if(isset($_SESSION['getid'])){?>
            <div id="">
                <h1>sdsd</h1>
            </div>
            <?php 
            //unset session
                unset($_SESSION['getid']); } ?>
                <div class="p-2">
                  <label>Choose Semester</label>

             <select class="form-select" name="choosesem" id="choosesem"  aria-label="">
                <option value="1">First Semester</option>
                <option value="2">Second Semester</option>
                <option value="3">Third Semester</option>
                <option value="4">Fourth Semester</option>
             </select>
                </div>
              <br>
            <div class="table-responsive" id="">
              <table class="table align-items-center ">
                <thead style="text-align: center;">
                    <tr>
                        <th>No.</th>
                        <th>Subject</th>
                        <th>Teacher</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <!-- where the semester grades will show -->
                <tbody style="text-align: center;" id="findtbl">
                    
                </tbody>
              
              </table>
            </div>
            
            </div>
            </div>
          </div>
          
        
        
        
        </div>
        </div>

       
       
      </div>
     
    </div>
  </main>
  
  <!--   Core JS Files   -->
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <script src="./assets/js/sweetalert2.js"></script>
  <script>
   
  </script>
  <script>
    var search = "";
    $("#showg").hide();
    $("#viewg").on('click', function(event) {
        
        $("#showg").show();
        $("#other").hide();

        

    
    });
    // function semfunc(){
    //   alert("Asd");
    // }
    $("#choosesem").on('change', function(event){
        var sem = $(this).val();
        $.ajax({
                url: "student_back.php",
                method: "POST",
                data: {
                    sem: sem,
                },
                success:function(data){
                    $("#findtbl").html(data);
                   
                   
                }
            })
    });
    
  </script>
  <?php
  if(isset($_SESSION['status']) && $_SESSION['status'] !=''){
    ?>
    <script>
        Swal.fire({
            icon: "<?php  echo $_SESSION['status']; ?>",
            text: "<?php  echo $_SESSION['message']; ?>",
        
            });
     

    </script>
    <?php
 
    unset($_SESSION['status']);
  }
  
  ?>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/argon-dashboard.min.js?v=2.0.4"></script>
</body>

</html>